import java.net.*;
import java.io.*;

/**
 * Cliente UDP básico en Java.
 * Envía mensajes a un servidor en el puerto 6000 usando datagramas.
 * Los mensajes se introducen por consola y se envían hasta que se escriba "fin".
 */
public class socketudpcli {
   public static void main(String argv[]) {
      // Verifica que se haya pasado la dirección del servidor 
      if (argv.length == 0) {
         System.err.println("Uso: java socketudpcli <servidor>");
         System.exit(1);
      }

      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

      System.out.println("Prueba de sockets UDP (cliente)");

      DatagramSocket socket;   // Socket UDP para enviar datagramas
      InetAddress address;     // Dirección del servidor
      byte[] mensaje_bytes = new byte[256];
      String mensaje = "";
      DatagramPacket paquete;  // Paquete que encapsula el mensaje

      try {
         // Creación del socket UDP sin puerto fijo 
         System.out.print("Creando socket... ");
         socket = new DatagramSocket();
         System.out.println("ok");

         // Obtiene la dirección IP del servidor 
         System.out.print("Capturando dirección de host... ");
         address = InetAddress.getByName(argv[0]);
         System.out.println("ok");

         System.out.println("Introduce mensajes a enviar (escribe 'fin' para salir):");

         // Bucle de envío de mensajes hasta que el usuario escriba "fin"
         do {
            mensaje = in.readLine();  // Captura entrada de usuario
            mensaje_bytes = mensaje.getBytes(); 
            
            // Crea paquete con el mensaje y lo envía al servidor en el puerto 6000
            paquete = new DatagramPacket(mensaje_bytes, mensaje.length(), address, 6000);
            socket.send(paquete);
         } while (!mensaje.startsWith("fin"));
      }
      catch (Exception e) {
         // Manejo de excepciones 
         System.err.println("Error: " + e.getMessage());
         System.exit(1);
      }
   }
}
