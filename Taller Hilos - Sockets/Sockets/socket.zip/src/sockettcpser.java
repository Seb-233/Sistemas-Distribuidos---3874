import java.net.*;
import java.io.*;

/**
 * Servidor TCP básico en Java.
 * Escucha conexiones en el puerto 6001, acepta un cliente y muestra
 * en consola los mensajes que recibe.
 */
public class sockettcpser {
   public static void main(String argv[]) {
      System.out.println("Prueba de sockets TCP (servidor)");

      ServerSocket socket;   // Socket servidor que escucha conexiones

      try {
         // Se abre el puerto 6001 para escuchar peticiones entrantes
         socket = new ServerSocket(6001);
         System.out.println("Servidor escuchando en el puerto 6001...");

         // Se acepta la conexión de un cliente
         Socket socket_cli = socket.accept();
         System.out.println("Cliente conectado desde: " + socket_cli.getInetAddress());

         // Flujo de entrada para recibir datos del cliente
         DataInputStream in = new DataInputStream(socket_cli.getInputStream());

         // Bucle infinito para recibir mensajes
         while (true) {
            String mensaje = in.readUTF();   // Lee mensaje enviado por el cliente
            System.out.println("Cliente: " + mensaje);
         }
      }
      catch (Exception e) {
         // Captura errores relacionados con sockets 
         System.err.println("Error: " + e.getMessage());
         System.exit(1);
      }
   }
}
