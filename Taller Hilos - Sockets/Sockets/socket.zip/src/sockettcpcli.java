import java.net.*;
import java.io.*;

/**
 * Cliente TCP básico en Java.
 * Se conecta a un servidor en el puerto 6001 y envía mensajes desde consola
 * hasta que el usuario escriba "fin".
 */
public class sockettcpcli {
   public static void main(String argv[]) {
      // Verifica si se proporcionó la dirección del servidor como argumento
      if (argv.length == 0) {
         System.err.println("Uso: java sockettcpcli <servidor>");
         System.exit(1);
      }

      BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

      System.out.println("Prueba de sockets TCP (cliente)");

      Socket socket;
      InetAddress address;
      String mensaje = "";

      try {
         // Obtiene la dirección IP a partir del nombre o IP proporcionada
         System.out.print("Capturando dirección de host... ");
         address = InetAddress.getByName(argv[0]);
         System.out.println("ok");

         // Crea el socket para conectarse al servidor en el puerto 6001
         System.out.print("Creando socket... ");
         socket = new Socket(address, 6001);
         System.out.println("ok");

         // Canal de salida para enviar datos al servidor
         DataOutputStream out = new DataOutputStream(socket.getOutputStream());

         System.out.println("Introduce mensajes a enviar (escribe 'fin' para salir):");

         // Bucle de envío de mensajes hasta que se escriba "fin"
         do {
            mensaje = in.readLine();      // Lee línea de entrada
            out.writeUTF(mensaje);        // Envía el mensaje al servidor
         } while (!mensaje.startsWith("fin"));
      }
      catch (Exception e) {
         // Captura y muestra errores de conexión 
         System.err.println("Error: " + e.getMessage());
         System.exit(1);
      }
   }
}
