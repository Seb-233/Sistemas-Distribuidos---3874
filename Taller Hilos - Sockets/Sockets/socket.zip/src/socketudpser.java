import java.net.*;
import java.io.*;

/**
 * Servidor UDP básico en Java.
 * Escucha en el puerto 6000 y recibe mensajes enviados por clientes.
 * Finaliza cuando recibe el mensaje "fin".
 */
public class socketudpser {
   public static void main(String argv[]) {
      System.out.println("Prueba de sockets UDP (servidor)");

      DatagramSocket socket;  // Socket UDP que escucha en un puerto
      boolean fin = false;    // Bandera para terminar el servidor

      try {
         // Crea el socket en el puerto 6000
         System.out.print("Creando socket... ");
         socket = new DatagramSocket(6000);
         System.out.println("ok");

         System.out.println("Recibiendo mensajes... ");

         // Bucle de recepción de mensajes
         do {
            byte[] mensaje_bytes = new byte[256]; // Buffer para el mensaje
            DatagramPacket paquete = new DatagramPacket(mensaje_bytes, 256);

            // Espera hasta recibir un datagrama
            socket.receive(paquete);

            // Convierte los bytes recibidos a String 
            String mensaje = new String(paquete.getData(), 0, paquete.getLength());

            // Muestra mensaje recibido y la dirección del cliente
            System.out.println("Cliente [" + paquete.getAddress() + "]: " + mensaje);

            // Condición de fin: si el mensaje empieza con "fin"
            if (mensaje.startsWith("fin")) fin = true;
         } while (!fin);

         System.out.println("Servidor finalizado.");
      }
      catch (Exception e) {
         // Manejo de errores en caso de fallos de red o I/O
         System.err.println("Error: " + e.getMessage());
         System.exit(1);
      }
   }
}
